package com.simReg;

import java.io.IOException;
import java.io.PrintWriter;

//import servlet

import javax.servlet.*;

public class SimpleRegistrationForm implements Servlet {
	
	//writing lifecycle methods first
	
	@Override
	public void init(ServletConfig init) {
		System.out.println("server has been initiated");
	}
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException{
		System.out.println("server servicing");
		
		res.setContentType("text/html");
		 PrintWriter pw= res.getWriter();
		 pw.println("<form><input>hello</input></form>");
	}
	
	@Override
	public void destroy() {
		
		System.out.println("server destroyed");
		
	}
	@Override
	public String getServletInfo() {
		return null;
		
	}
	@Override
	public ServletConfig getServletConfig() {
		return null;
		
	}
}
