package net.javaguides.registration.dao;
import java.sql.*;

import com.mysql.cj.exceptions.RSAException;

import net.javaguides.registration.model.Employee;


public class EmployeeDao {
//this class is basically to connect to database
	public int registration(Employee employee)  throws ClassNotFoundException, SQLException{
		String insert_into_db = "insert into employeedetails" + 
	"(empId,firstName,lastName,userName, password, address, contact) values" +  
				"(?,?,?,?,?,?,?)" ;
		
		int result = 0;
		
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/database_1","root","root");
		PreparedStatement stmt = connection.prepareStatement(insert_into_db);
		try {
			stmt.setInt(1, 1);
			stmt.setString(2, employee.getFname());
			stmt.setString(3, employee.getLname());
			stmt.setString(4, employee.getUname());
			stmt.setString(5, employee.getPswrd());
			stmt.setString(6, employee.getAddress());
			stmt.setString(7, employee.getContact());
			
			System.err.println(stmt);
			
			result = stmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	
	}
	
}
