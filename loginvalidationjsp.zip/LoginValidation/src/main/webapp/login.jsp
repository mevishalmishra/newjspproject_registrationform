<%@page import="java.sql.DriverManager"%>
<%

String  uname = request.getParameter("uname");
String  pswrd = request.getParameter("pswrd");











if(uname.equals("vishal") && pswrd.equals("vishal"))
{
	out.println("login success");
}
else{
	out.println("login failed");
}






%>