package com.vishal;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

public class AddServlet extends HttpServlet{
	
	

	public void service(HttpServletRequest rq, HttpServletResponse res)
	{
	
		
		int a = Integer.parseInt(rq.getParameter("num1"));
		int b= Integer.parseInt(rq.getParameter("num2"));
		String name = rq.getParameter("uname");
		int c = a + b;
		
		
		
		
		
		HttpSession session = rq.getSession(true);
		session.setAttribute("username",name);
		
		
		
		
		
		try {
			res.getWriter().println("hello master : " + session.getAttribute("username"));
			res.getWriter().println("the answer is : " + c);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
